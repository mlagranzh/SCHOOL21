# fract-ol

Fract'ol is a School 42 project. The purpose of this project is to create fractal renderer.
For writing this project
1. Read wiki page
2. Read about minilibx library
3. Start code, Good luck

## Wiki

You can check [wiki-pages](https://github.com/VBrazhnik/Fract-ol/wiki) if you want to read detailed explanations and tips. Wiki-pages were written **in Russian**.

But here is my [wiki](../../wiki/). I translated **in English**.

Tutorial for [Minilibx](https://harm-smits.github.io/42docs/libs/minilibx/getting_started.html) library




